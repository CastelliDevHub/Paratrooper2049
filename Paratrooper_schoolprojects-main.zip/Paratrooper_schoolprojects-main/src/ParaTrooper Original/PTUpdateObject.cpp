// PTUpdateObject.cpp: implementation of the CPTUpdateObject class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PT.h"
#include "PTUpdateObject.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPTUpdateObject::CPTUpdateObject()
{

}

CPTUpdateObject::~CPTUpdateObject()
{

}
