//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PT.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_PTTYPE                      129
#define IDB_HELI                        133
#define IDB_HELITOLEFTRED               133
#define IDD_OPTIONS                     135
#define IDD_HISCORES                    136
#define IDD_BEGIN                       137
#define IDB_GUNBODY                     140
#define IDB_BKGR1                       141
#define IDB_PLANE1                      142
#define IDB_PLANETOLEFTGREY             142
#define IDB_PLANEEXP1                   143
#define IDB_PLANEEXP2                   144
#define IDB_PLANEEXP3                   145
#define IDB_BULLET                      152
#define IDB_COMICFONT                   153
#define IDB_LIFE                        155
#define IDB_CLOUD1                      158
#define IDB_EXPLOSION                   168
#define IDB_EXPLOSION2                  172
#define IDB_BKGR3                       173
#define IDB_BKGR2                       174
#define IDB_TROOPLAND                   179
#define IDB_CHUTE                       180
#define IDB_TROOPFALL                   181
#define IDB_CHINOOK                     183
#define IDB_HELITORIGHTPURP             184
#define IDB_HELITOLEFTPURP              185
#define IDB_HELITOLEFTGREEN             186
#define IDB_HELITORIGHTGREEN            187
#define IDB_HELITORIGHTRED              188
#define IDB_SPLATGROUND                 196
#define IDB_SPLATAIR                    197
#define IDB_PLANETORIGHTGREY            198
#define IDB_PLANETORIGHTGREEN           199
#define IDB_PLANETOLEFTGREEN            200
#define IDB_BOMB                        201
#define IDB_OPTIONS                     205
#define IDB_OPTIONSCOVER                212
#define IDB_BITMAP1                     213
#define IDB_STATS                       213
#define IDB_OKBTN                       214
#define IDB_OKBTNF                      215
#define IDB_NOBTN                       216
#define IDB_NOBTNF                      217
#define IDC_EDIT1                       1000
#define IDC_Level                       1000
#define IDC_Lifes                       1001
#define IDC_Points                      1002
#define IDC_Name                        1003
#define IDC_DIFF                        1004
#define IDC_SOUND                       1011
#define IDC_SPIN1                       1013
#define IDC_DIFFSPIN                    1013
#define IDC_SHOTBULLETS                 1014
#define IDC_TROOPS                      1016
#define IDC_TROOPC                      1018
#define IDC_HELIC                       1019
#define IDC_HELIS                       1020
#define IDC_CHUTES                      1021
#define IDC_BOMBC                       1022
#define IDC_BOMBS                       1023
#define IDC_PLANEC                      1024
#define IDC_PLANES                      1025
#define IDC_TROOPL                      1026
#define IDC_ACCURACY                    1027
#define IDC_SKILL                       1028
#define ID_GAME_OPTIONS                 32771
#define ID_GAME_HISCORES                32772
#define IDS_STRINGERRORNEWDOC           61204

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        219
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
