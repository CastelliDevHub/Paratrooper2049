# Paratrooper_schoolprojects

Gemaakt tijdens m'n studies op de Paardenmarkt. Code is geen weergave van m'n huidige programmeerervaring..het gaat om een studentenproject van me begin van dit millenium ;)
